import java.awt.Color;

import javax.swing.JButton;

public class Check {

	public static boolean isSurroundingByWhiteSpace(JButton[][] buttons) {
		boolean check = false;
		JButton focusButton = null;
		int focusX = 0;
		int focusY = 0;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (buttons[i][j].getBackground().equals(Color.BLACK)) {
					focusX = i;
					focusY = j;
					focusButton = buttons[i][j];
					System.out.printf("X = %d, Y = %d", focusX, focusY);

					if ((focusX >= 1 && focusX <= 3)
							&& (focusY >= 1 && focusY <= 3)) {

						check = buttons[focusX - 1][focusY].getBackground()
								.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX + 1][focusY].getBackground()
									.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX][focusY - 1].getBackground()
									.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX][focusY + 1].getBackground()
									.equals(Color.WHITE) ? true : false;
						if (check)
							System.out.println("Level1");
					} else if ((focusX == 0 && focusY == 0)
							|| (focusX == 0 && focusY == 4)) {
						if (focusY == 0) {
							check = buttons[0][1].getBackground().equals(
									Color.WHITE) ? true : false;
							if (check)
								check = buttons[1][0].getBackground().equals(
										Color.WHITE) ? true : false;
						} else if (focusY == 4) {
							check = buttons[0][3].getBackground().equals(
									Color.WHITE) ? true : false;
							if (check)
								check = buttons[1][4].getBackground().equals(
										Color.WHITE) ? true : false;
						}
						if (check)
							System.out.println("level2");

					} else if ((focusX == 4 && focusY == 0)
							|| (focusX == 4 && focusY == 4)) {
						if (focusY == 0) {
							check = buttons[3][0].getBackground().equals(
									Color.WHITE) ? true : false;
							if (check)
								check = buttons[4][1].getBackground().equals(
										Color.WHITE) ? true : false;
						} else if (focusY == 4) {
							check = buttons[3][4].getBackground().equals(
									Color.WHITE) ? true : false;
							if (check)
								check = buttons[4][3].getBackground().equals(
										Color.WHITE) ? true : false;
						}
						if (check)
							System.out.println("level3");

					} else if (focusX == 0 && focusY >= 1 && focusY <= 3) {
						check = buttons[focusX][focusY - 1].getBackground()
								.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX][focusY + 1].getBackground()
									.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX + 1][focusY].getBackground()
									.equals(Color.WHITE) ? true : false;

						if (check)
							System.out.println("level4");
					} else if (focusX == 4 && focusY >= 1 && focusY <= 3) {
						check = buttons[focusX][focusY - 1].getBackground()
								.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX][focusY + 1].getBackground()
									.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX - 1][focusY].getBackground()
									.equals(Color.WHITE) ? true : false;

						if (check)
							System.out.println("level5");
					} else if (focusY == 0 && focusX >= 1 && focusX <= 3) {
						check = buttons[focusX - 1][focusY].getBackground()
								.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX + 1][focusY].getBackground()
									.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX][focusY + 1].getBackground()
									.equals(Color.WHITE) ? true : false;

						if (check)
							System.out.println("level6");
					} else if (focusY == 4 && focusX >= 1 && focusX <= 3) {
						check = buttons[focusX - 1][focusY].getBackground()
								.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX + 1][focusY].getBackground()
									.equals(Color.WHITE) ? true : false;
						if (check)
							check = buttons[focusX][focusY - 1].getBackground()
									.equals(Color.WHITE) ? true : false;

						if (check)
							System.out.println("level7");
					}

				}

			}
		}

		return check;
	}

	public static boolean isNotBlackSpace(JButton[][] buttons) {
		boolean check = false;
		int focusX = 0;
		int focusY = 0;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {

				if (buttons[i][j].getBackground().equals(Color.WHITE)) {
					focusX = i;
					focusY = j;
					System.out.printf("X = %d, Y = %d", focusX, focusY);
					for (int x = 0; x < 5; x++) {
						if (x != focusX) {
							if (buttons[x][focusY].getText().equals(
									buttons[focusX][focusY].getText()) && !buttons[x][focusY].getBackground()
									.equals(Color.BLACK)) {
								System.out.println("****X****");	
								check = true;
									break;
									
								}

								
							}
						}
					}
//					System.out.println("leve 8, check = " + check);
					if (!check) {
						for (int y = 0; y < 5; y++) {
							// check = buttons
							if (y != focusY) {
								if (buttons[focusX][y].getText().equals(
										buttons[focusX][focusY].getText()) && !buttons[focusX][y].getBackground()
										.equals(Color.BLACK)) {
									System.out.println("****Y****");
									check = true;
									break;
								}

							}
						}
					}
					if(check){
						break;
					}
				}
			}
		System.out.println("leve 9, check = " + check);
		if (!check)
			System.out.printf("level 10");
	
		return check;
	}
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package hitorigame;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.EventListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author ALESON
 */
public class HitoriGame {

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here

		JFrame frame = new JFrame("Hitori!");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel j1 = new JPanel();
		JPanel j2 = new JPanel();
		j1.setLayout(new GridLayout(5, 5));
		frame.setSize(230, 210);
		// frame.setLayout(new GridLayout(2,1));

		int GRAY = 1;
		int BLACK = 2;
		int WHITE = 3;

		int forColor = 0;

		int[] a = { 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 4, 4, 4, 4,
				5, 5, 5, 5, 5 };
		final JButton[] button = new JButton[25];
		final JButton[][] into2D = new JButton[5][5];

		Random rando = new Random();
		int[] countIndex = new int[25];

		int[][] currentColor = new int[5][5];

		for (int i = 0; i < 25; i++) {
			if (i < 5) {// it will initialize initial color for button
				for (int j = 0; j < 5; j++) {
					currentColor[i][j] = GRAY;
				}
			}
			int temp = rando.nextInt(24);
			countIndex[i] = temp;

			for (int x : countIndex) {
				if (x != i) {
					button[i] = new JButton("" + a[temp]);
					button[i].setBackground(Color.GRAY);

					button[i].addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {

							Object source = e.getSource();

							if (source instanceof Component) {
								if (((Component) source).getBackground() == Color.GRAY) {
									((Component) source)
											.setBackground(Color.BLACK);
									((Component) source)
											.setForeground(Color.WHITE);

								} else if (((Component) source).getBackground() == Color.BLACK) {
									((Component) source)
											.setBackground(Color.WHITE);
									((Component) source)
											.setForeground(Color.BLACK);

								} else if (((Component) source).getBackground() == Color.WHITE) {
									((Component) source)
											.setBackground(Color.GRAY);
									((Component) source)
											.setForeground(Color.BLACK);
								}
							}

						}
					});

				}
			}

			j1.add(button[i]);

		}

		JButton check = new JButton("Check");
		check.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int x = 0;
				int y = 0;
				boolean result = true;
				for (int i = 0; i < 25; i++) {

					into2D[x][y] = button[i];
					y++;
					if ((i + 1) % 5 == 0) {
						x++;
						y = 0;
					}

				}
//				Check.isNotBlackSpace(into2D);
			
				if (Check.isSurroundingByWhiteSpace(into2D)
						&& !Check.isNotBlackSpace(into2D)) {
					JOptionPane.showMessageDialog(null, "Congrats! you win",
							"Result", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "Try Again", "Result",
							JOptionPane.ERROR_MESSAGE);
					System.exit(0);

 }
			}

		});

		j2.add(check);
		frame.setLayout(new FlowLayout());
		frame.setVisible(true);
		frame.add(j1);
		frame.add(j2);

	}
}
